#!/usr/bin/env python3
"""Compose la vidéo d'ouverture Golden Head Spa à partir des frames B1..B8 (fondus temporels, cadrage fixe).
Usage: python3 build_opening.py <dossier_frames> <sortie_dir>
Production : composition locale (numpy + FFmpeg), PAS un moteur image-vers-vidéo."""
import subprocess, sys, os
import numpy as np
from PIL import Image

src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
names = ['B1_Calme','B2_Premiere_goutte','B3_Ecoulement','B4_Premieres_volutes',
         'B5_Vapeur_montante','B6_Brume_dense','B7_Logo_apparition','B8_Logo_final']
# début de chaque plan (s) ; chaque fondu est centré sur la frontière
bounds = [0.7, 1.3, 2.3, 3.3, 4.5, 5.8, 6.8]
FADE, FPS, DUR = 0.6, 30, 8.0
W, H = 1024, 1536
imgs = [np.asarray(Image.open(f'{src}/{n}.png').convert('RGB'), dtype=np.float32) for n in names]
assert all(i.shape == (H, W, 3) for i in imgs)

def smooth(x): x = min(max(x, 0.0), 1.0); return x*x*(3-2*x)

def frame(t):
    k = 0
    for i, b in enumerate(bounds):
        if t >= b + FADE/2: k = i + 1
    if k < len(bounds):
        b = bounds[k]
        w = smooth((t - (b - FADE/2)) / FADE)
        if w > 0: return imgs[k]*(1-w) + imgs[k+1]*w
    return imgs[k]

ff = subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}',
    '-r',str(FPS),'-i','-','-c:v','libx264','-preset','slow','-crf','20','-pix_fmt','yuv420p',
    '-movflags','+faststart','-an','-r',str(FPS), f'{out}/opening-golden-head-spa.mp4'], stdin=subprocess.PIPE)
for n in range(int(DUR*FPS)):
    ff.stdin.write(np.clip(frame(n/FPS),0,255).astype(np.uint8).tobytes())
ff.stdin.close(); ff.wait()
Image.open(f'{src}/B8_Logo_final.png').convert('RGB').save(f'{out}/opening-poster.jpg', quality=88)
Image.open(f'{src}/B1_Calme.png').convert('RGB').save(f'{out}/opening-first.jpg', quality=88)
print('ok')
