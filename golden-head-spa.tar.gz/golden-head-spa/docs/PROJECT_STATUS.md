# Statut du projet — fin de Phase 2 + écrans de la Phase 3

## Vérifié réellement
- `pnpm -r typecheck` : OK (5 workspaces, strict).
- Tests Vitest `@ghs/validation` : 3/3 OK.
- `expo export --platform android` : bundle Hermes généré sans erreur (5,3 Mo).
## Non vérifié
- Rendu visuel sur appareil/simulateur iOS et Android (aucun émulateur ici) → **fidélité à la maquette non validée visuellement**.
- Build iOS, EAS, tests E2E, lint.
## Écrans livrés
Onboarding, accueil, rituels (filtres), fiche rituel, réservation (choix du soin + redirection Planity), carte cadeau (formulaire validé), boutique (état vide), compte (formulaire validé), menu, entreprises & CE (formulaire validé), à propos, contact.
## Simulé / bloqué (honnêtement)
| Fonction | État |
|---|---|
| Réservation native | Non faite : Planity sans API confirmée. Bouton actif vers l'URL Planity officielle (redirection non testée sur appareil) |
| Connexion / inscription | Formulaire + validation seulement ; Supabase non connecté |
| Paiement carte cadeau | Non branché (Stripe) ; aucune carte émise |
| Envoi demande entreprise | Validation seulement |
| Boutique | Vide, achats désactivés |
| Avis | 4 extraits anonymes du visuel client, à remplacer par avis vérifiés |
| Admin Next.js, notifications, RGPD (export/suppression), sentry | Non démarrés (phases 4–6) |
## Accès / éléments manquants (propriétaire)
1. ~~URL Planity~~ reçue (golden-hair-spa-60200-compiegne). Reste : confirmation d'une éventuelle API partenaire.
2. Accès/export du site (WooCommerce ? catalogue produits réel, textes, photos HD, logo vectoriel).
3. Projet Supabase (URL + clé anon) ; clé service_role côté serveur uniquement.
4. Comptes Stripe, Resend, Sentry, Vercel, Expo (EAS), Apple Developer, Google Play Console.
5. Bundle IDs définitifs (provisoire : `com.damcompany.goldenheadspa`), URL réseaux sociaux, CGV/politique de confidentialité, validité réelle des cartes cadeaux.
6. Validation des catégories de rituels et descriptions (hypothèses actuelles).
## Mise à jour 15/10 (captures du site/Planity)
Catalogue passé à 8 rituels avec descriptions réelles, catégories Head Spa / Massage / Enfant, téléphone, note 5,0 (432 avis), règles de cartes cadeaux. Écarts à trancher : voir AUDIT.md §7 (horaires, durée Kids).
## Hypothèses à confirmer
Samedi/dimanche : horaires non connus. `typescript` 5.9 installé (Expo recommande 6.0) — sans impact constaté.

## Mise à jour 05/11 — demandes d'Inès (entrée immersive, musique, offres flash, chat IA)
**Vérifié** : typecheck OK ; tests Vitest OK (validation 5/5, chat 7/7) ; rendu web testé (entrée, offres verrouillées/membre démo, chat en repli).
- **Entrée immersive** : écran plein cadre à chaque ouverture (photo en lente respiration, textes en fondu, bouton « Entrer »). Respecte « réduire les animations ».
- **Musique** : lecteur prêt (expo-audio, fondu, boucle, bouton couper/relancer mémorisé). **Aucun fichier fourni** → rien ne joue et le bouton est masqué. Activation : déposer `assets/audio/ambient.mp3` et modifier `src/data/audio.ts`. Le son démarre au toucher sur « Entrer » (les navigateurs bloquent l'autoplay).
- **Offres flash** : écran avec compte à rebours, réservé aux membres. Table `flash_offers` + RLS (lecture : utilisateurs authentifiés, offres actives en cours ; écriture : admin) dans `supabase/migrations/20261105000000_flash_offers.sql`, non appliquée. **Données de démo** étiquetées « DÉMO ». Mode démo membre activé seulement si `EXPO_PUBLIC_DEMO_MODE=1`. **Non fait** : interface d'admin pour créer les offres (admin Next.js pas encore créé) ; mécanisme réel d'application de la remise (Planity ne le permet pas a priori) à décider avec Inès.
- **Chat IA** : écran de chat + route serveur `apps/mobile/api/chat.ts` (Vercel Function) appelant l'API Anthropic. Clé uniquement côté serveur. Le prompt contient seulement les infos réelles (rituels, prix, horaires, règles cartes cadeaux), ne confirme aucun créneau, renvoie vers Planity / email / téléphone, pas de conseil médical. Validation Zod, limite de 20 requêtes / 10 min / IP (en mémoire, à remplacer par un store partagé en production). **Non testé avec la vraie API** (pas de clé) : il faut `ANTHROPIC_API_KEY` dans Vercel. Sans clé : message de repli + boutons écrire/appeler.
- **À valider** : mention « assistant IA » (affichée), conservation/RGPD des conversations (rien n'est stocké pour l'instant), modèle (`ANTHROPIC_MODEL`, défaut claude-haiku-4-5).
