import { describe, expect, it } from 'vitest';
import { chatRequestSchema, flashOfferSchema, giftCardPurchaseSchema, signUpSchema } from './index';

describe('validation', () => {
  it('rejette un mot de passe court', () => {
    const r = signUpSchema.safeParse({ fullName: 'Lea Dupont', email: 'a@b.fr', password: 'court', acceptTerms: true });
    expect(r.success).toBe(false);
  });
  it('accepte une carte cadeau valide', () => {
    const r = giftCardPurchaseSchema.safeParse({ amountEur: 80, recipientName: 'Lea', recipientEmail: 'lea@x.fr' });
    expect(r.success).toBe(true);
  });
  it('rejette un montant hors bornes', () => {
    const r = giftCardPurchaseSchema.safeParse({ amountEur: 5, recipientName: 'Lea', recipientEmail: 'lea@x.fr' });
    expect(r.success).toBe(false);
  });
  it('refuse une offre flash qui finit avant de commencer', () => {
    const r = flashOfferSchema.safeParse({ title: 'Flash', discountPercent: 20, startsAt: '2026-11-10T10:00:00Z', endsAt: '2026-11-09T10:00:00Z' });
    expect(r.success).toBe(false);
  });
  it('refuse un chat dont le dernier message est de l\'assistant', () => {
    expect(chatRequestSchema.safeParse({ messages: [{ role: 'assistant', content: 'Bonjour' }] }).success).toBe(false);
    expect(chatRequestSchema.safeParse({ messages: [{ role: 'user', content: 'Bonjour' }] }).success).toBe(true);
  });
});
